function sumar(numA, numB) {
    return numA + numB;
}
module.exports = sumar;