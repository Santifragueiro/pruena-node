function multiplicar(numeroA, numeroB){
    return numeroA * numeroB;
};
module.exports = multiplicar;