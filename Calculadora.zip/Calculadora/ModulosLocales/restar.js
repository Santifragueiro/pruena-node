function restar (numero1, numero2){
    return numero1 - numero2;
}
module.exports = restar;